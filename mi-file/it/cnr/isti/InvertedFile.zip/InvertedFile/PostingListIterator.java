/*
 * PostingListIterator.java
 *
 * Created on 19 aprile 2007, 17.12
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package it.cnr.isti.InvertedFile;
import java.util.*;
import java.io.*;
import java.nio.*;

/**
 *
 * @author amato
 */
public class PostingListIterator implements Iterator
{

    private MappedByteBuffer postingListMemoryMapped;
    private int postingListIndex[];
    static private int elementSize=1*4; //We store just the object identifier, not the score
    private long fromPos;
    private long toPos;
    private long currentPos;
    private int currentScore;
    static private long numOfReads=0;

    //private boolean inUse=false;
   
    
    
    /** Creates a new instance of PostingListIterator */
    public PostingListIterator(MappedByteBuffer postingListMemoryMapped, int postingListIndex[],int fromScoreParam, int toScoreParam){
        this.postingListMemoryMapped=postingListMemoryMapped;
        this.postingListIndex=postingListIndex;
        if(this.postingListMemoryMapped!=null){
            currentScore=Math.max(fromScoreParam,0);
            try{
                currentPos=fromPos=this.postingListIndex[Math.max(fromScoreParam,0)];
            }catch(Exception e){
                e.printStackTrace();
            }
            toPos=postingListIndex[Math.min(toScoreParam+1,postingListIndex.length-1)];
        }
    }

    public int getPostingListSize(){
        return (postingListIndex[postingListIndex.length-1]-postingListIndex[0])/elementSize;
    }

    public int getPostingListPortionSize(){
        return (int)(toPos-fromPos)/elementSize;
    }
    
    
    
/*    public PostingListIterator(RandomAccessFile[] invFileParam,int[][] postingListIndexPar,MappedByteBuffer[] plsPar,int entryParam, int fromScoreParam, int toScoreParam, String p_indexDirectory) {
        initialisation(invFileParam,postingListIndexPar,plsPar,entryParam,fromScoreParam,toScoreParam,p_indexDirectory);
    }
    
    public PostingListIterator(RandomAccessFile[] invFileParam,int[][] postingListIndexPar,MappedByteBuffer[] plsPar,int entryParam, int fromScoreParam, String p_indexDirectory) {
         initialisation(invFileParam,postingListIndexPar,plsPar,entryParam,fromScoreParam,invFileParam.length,p_indexDirectory);
    }
    
    public PostingListIterator(RandomAccessFile[] invFileParam,int[][] postingListIndexPar,MappedByteBuffer[] plsPar,int entryParam, String p_indexDirectory) {
         initialisation(invFileParam,postingListIndexPar,plsPar,entryParam,0,invFileParam.length,p_indexDirectory);
    }*/
    
    static public void resetNumOfReads(){
        numOfReads=0;
    }
    
    static public int getElementSize(){
        return elementSize;
    }
    
    static public long getNumOfReads(){
        return numOfReads;
    }
    
    public void remove() throws UnsupportedOperationException{
        throw new UnsupportedOperationException("remove is not supported by InvertedFileIterator");
    }
    
    public synchronized PostingListEntry next() throws NoSuchElementException{
        if(postingListMemoryMapped!=null && 
                currentPos >=0 &&
                currentPos < toPos)
        {
            postingListMemoryMapped.position((int)currentPos-postingListIndex[0]);
            numOfReads++;
            int o=postingListMemoryMapped.getInt();
            while(currentPos>=postingListIndex[currentScore+1])
                currentScore++;
            int score=currentScore;
            currentPos+=elementSize;
//            System.out.println("Object:"+o+" Score:"+score);
            return new PostingListEntry(o,score);
        }
        throw new NoSuchElementException("InvertedFile not Initialized, non valid entry, or no more elements in this posting list");
    }
    
    public synchronized boolean hasNext(){
        if(postingListMemoryMapped!=null && 
                currentPos >=0 &&
                currentPos < toPos)
            return true;
        else
            return false;       
    }
    
}
