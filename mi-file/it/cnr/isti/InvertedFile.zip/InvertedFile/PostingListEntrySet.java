/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package it.cnr.isti.InvertedFile;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.util.Iterator;

/**
 *
 * @author Amato
 */
public class PostingListEntrySet extends java.util.AbstractSet<PostingListEntry>{

    final int fromScore, toScore;
    final private MappedByteBuffer postingListMemoryMapped;
    final private int postingListIndex[];


    public PostingListEntrySet(MappedByteBuffer[] memoryMappedPostingLists, int [][]postingListIndexes, int postingListId,String indexDirectory,int lexiconSize, int maxScore){
        memoryMapPostingList(postingListId, indexDirectory, maxScore, memoryMappedPostingLists, postingListIndexes);
        postingListMemoryMapped=memoryMappedPostingLists[postingListId];
        postingListIndex=postingListIndexes[postingListId];
        this.fromScore=0;
        this.toScore=maxScore;
    }

    public PostingListEntrySet(MappedByteBuffer[] memoryMappedPostingLists,int [][]postingListIndexes, int postingListId,String indexDirectory,int lexiconSize, int maxScore,int fromScore){
        memoryMapPostingList(postingListId, indexDirectory, maxScore, memoryMappedPostingLists, postingListIndexes);
        postingListMemoryMapped=memoryMappedPostingLists[postingListId];
        postingListIndex=postingListIndexes[postingListId];
        this.fromScore=fromScore;
        this.toScore=maxScore;

    }

    public PostingListEntrySet(MappedByteBuffer[] memoryMappedPostingLists,int [][]postingListIndexes, int postingListId,String indexDirectory,int lexiconSize, int maxScore,int fromScore, int toScore){
        memoryMapPostingList(postingListId, indexDirectory, maxScore, memoryMappedPostingLists, postingListIndexes);
        postingListMemoryMapped=memoryMappedPostingLists[postingListId];
        postingListIndex=postingListIndexes[postingListId];
        this.fromScore=fromScore;
        this.toScore=toScore;
    }
    
    private void memoryMapPostingList(int postingListId, String indexDirectory, int maxScore, MappedByteBuffer[] memoryMappedPostingLists, int[][] postingListIndexes  ){
        try{      
            File pl_f=new File(indexDirectory+"/invfile/pl_e"+postingListId+"_sorted.dat");
            RandomAccessFile postingListFile=null;
            if(postingListIndexes[postingListId]==null){
                if(pl_f.exists()){
                    postingListFile=new RandomAccessFile(pl_f,"r");
                    postingListIndexes[postingListId]=new int[maxScore+2]; //positions range from 0 up to maxScore+1 included
                    //Can we do the following by using MemoryMappedBuffers rather than random access files?
                    postingListFile.seek(0);
                    for(int s=0;s<postingListIndexes[postingListId].length;s++){
                        byte[] position_buff=new byte[4];
                        postingListFile.read(position_buff);
                        int position=Conversions.byteArrayToInt(position_buff);
                        postingListIndexes[postingListId][s]=position;
                    }
                }
            }                    
            if(memoryMappedPostingLists[postingListId]==null){
                if(postingListFile==null){
                    if(pl_f.exists()){
                        postingListFile=new RandomAccessFile(pl_f,"r");
                    }else
                        return; //cannot map becouse it does not exist
                }
                memoryMappedPostingLists[postingListId]=postingListFile.getChannel().map(java.nio.channels.FileChannel.MapMode.READ_ONLY,postingListIndexes[postingListId][0],postingListFile.length()-postingListIndexes[postingListId][0]);
            }
            if(postingListFile!=null)
                postingListFile.close();
        }catch(Exception e){
            System.err.println("Cannot open posting list");
            e.printStackTrace();    
        }
    }



    @Override
    public Iterator<PostingListEntry> iterator() {
        PostingListIterator iterator=new PostingListIterator(postingListMemoryMapped,postingListIndex,fromScore, toScore);
        return iterator;
    }

    @Override
    public int size() {
        PostingListIterator iterator=new PostingListIterator(postingListMemoryMapped,postingListIndex, fromScore, toScore);
        return iterator.getPostingListPortionSize();
    }


}
