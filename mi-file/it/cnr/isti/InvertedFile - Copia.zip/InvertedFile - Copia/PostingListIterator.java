/*
 * PostingListIterator.java
 *
 * Created on 19 aprile 2007, 17.12
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package it.cnr.isti.InvertedFile;
import java.util.*;
import java.io.*;
import java.nio.*;

/**
 *
 * @author amato
 */
public class PostingListIterator implements Iterator
{
    
    
    
    
    private RandomAccessFile postingListFile=null;
    private MappedByteBuffer postingListMemoryMapped;
    private int postingListIndex[];
    static private int elementSize=1*4; //We store just the object identifier, not the score
    private int entry;
    private int lexiconSize;
    private long fromPos;
    private long toPos;
    private long currentPos;
    private int currentScore;
    static private long numOfReads=0;

    private boolean inUse=false;
   
    
    
    /** Creates a new instance of PostingListIterator */
    public void initialisation(int fromScoreParam, int toScoreParam){
        synchronized(this){//one thread at time access one posting list
            if(postingListMemoryMapped!=null){
                if(inUse){
//                    System.out.println("Waiting for posting list "+entry+ "to become available");
                    try{
                        this.wait(10000); //one thread at time access one posting list. However if a tread takes too long we do not starve
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
//                System.out.println("Taking a lock on posting list "+entry);
                inUse=true;
                currentScore=Math.max(fromScoreParam,0);
                try{
                    currentPos=fromPos=postingListIndex[Math.max(fromScoreParam,0)];
                }catch(Exception e){
                    e.printStackTrace();
                }
                toPos=postingListIndex[Math.min(toScoreParam+1,postingListIndex.length-1)];
                postingListMemoryMapped.position((int)fromPos-postingListIndex[0]);
            }
        }
    }

    public int getPostingListSize(){
        return (postingListIndex[postingListIndex.length-1]-postingListIndex[0])/elementSize;
    }

    public int getPostingListPortionSize(){
        return (int)(toPos-fromPos)/elementSize;
    }
    
    public PostingListIterator(int entryPar,String indexDirectory,int lexiconSizePar, int maxScore){
        synchronized(this){
            entry=entryPar;
            lexiconSize=lexiconSizePar;
            try{
                File pl_f=new File(indexDirectory+"/invfile/pl_e"+entry+"_sorted.dat");
                if(pl_f.exists())
                {
                    if(postingListFile==null){
//                        System.out.println("Opening posting list "+entry);
                        postingListFile=new RandomAccessFile(pl_f,"r");
                    }
                    if(postingListIndex==null){
//                        System.out.println("Reading index of posting list "+entry);
                        postingListIndex=new int[maxScore+2]; //positions range from 0 up to maxScore+1 included
                        //Can we do the following by using MemoryMappedBuffers rather than random access files?
                        postingListFile.seek(0);
                        for(int s=0;s<postingListIndex.length;s++){
                            byte[] position_buff=new byte[4];
                            postingListFile.read(position_buff);
                            int position=Conversions.byteArrayToInt(position_buff);
                            postingListIndex[s]=position;
                        }
                    }                    
    //            System.out.println(fromScoreParam+" "+toScoreParam+" "+fromPos+" "+toPos);
    //                pl=invFile[entry].getChannel().map(java.nio.channels.FileChannel.MapMode.READ_ONLY,fromPos,toPos-fromPos);
                    if(postingListMemoryMapped==null){
                        postingListMemoryMapped=postingListFile.getChannel().map(java.nio.channels.FileChannel.MapMode.READ_ONLY,postingListIndex[0],postingListFile.length()-postingListIndex[0]);
                    }
                }
                else{
                    currentPos=fromPos=toPos=0;
                }
            }catch(Exception e){
                System.err.println("Cannot open posting list");
                e.printStackTrace();    
            }
        }
    }
    
    public void close(){
        try{
            postingListFile.getChannel().close();
            postingListFile.close();
            postingListFile=null;
            postingListMemoryMapped=null;
            postingListIndex=null;
        }catch(Exception e){
            System.err.println("Failed to close a posting list");
            e.printStackTrace();
        }
    }
    
    
/*    public PostingListIterator(RandomAccessFile[] invFileParam,int[][] postingListIndexPar,MappedByteBuffer[] plsPar,int entryParam, int fromScoreParam, int toScoreParam, String p_indexDirectory) {
        initialisation(invFileParam,postingListIndexPar,plsPar,entryParam,fromScoreParam,toScoreParam,p_indexDirectory);
    }
    
    public PostingListIterator(RandomAccessFile[] invFileParam,int[][] postingListIndexPar,MappedByteBuffer[] plsPar,int entryParam, int fromScoreParam, String p_indexDirectory) {
         initialisation(invFileParam,postingListIndexPar,plsPar,entryParam,fromScoreParam,invFileParam.length,p_indexDirectory);
    }
    
    public PostingListIterator(RandomAccessFile[] invFileParam,int[][] postingListIndexPar,MappedByteBuffer[] plsPar,int entryParam, String p_indexDirectory) {
         initialisation(invFileParam,postingListIndexPar,plsPar,entryParam,0,invFileParam.length,p_indexDirectory);
    }*/
    
    static public void resetNumOfReads()
    {
        numOfReads=0;
    }
    
    static public int getElementSize(){
        return elementSize;
    }
    
    static public long getNumOfReads()
    {
        return numOfReads;
    }
    
    public void remove() throws UnsupportedOperationException
    {
        throw new UnsupportedOperationException("remove is not supported by InvertedFileIterator");
    }
    
    public PostingListEntry next() throws NoSuchElementException
    {
        if(postingListMemoryMapped!=null && 
                entry >=0 && 
                entry < lexiconSize &&
                currentPos >=0 &&
                currentPos < toPos)
        {
            numOfReads++;
            int o=postingListMemoryMapped.getInt();
            while(currentPos>=postingListIndex[currentScore+1])
                currentScore++;
            int score=currentScore;
            currentPos+=elementSize;
//            System.out.println("Object:"+o+" Score:"+score);
            return new PostingListEntry(o,score);
        }
        synchronized(this){
//            System.out.println("Releasing lock on posting list "+entry);
            inUse=false;
            this.notify(); //release exclusive access to the posting list
        }
        throw new NoSuchElementException("InvertedFile not Initialized, non valid entry, or no more elements in this posting list");
    }
    
    public boolean hasNext()
    {
        if(postingListMemoryMapped!=null && 
                entry >=0 && 
                entry < lexiconSize &&
                currentPos >=0 &&
                currentPos < toPos)
            return true;
        else{
            synchronized(this){
//                System.out.println("Releasing lock on posting list "+entry);
                inUse=false;
                this.notify(); //release exclusive access to the posting list
            }
            return false;
        }
         
    }
    
}
