/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package it.cnr.isti.InvertedFile;

import java.util.Iterator;

/**
 *
 * @author Amato
 */
public class PostingListEntrySet extends java.util.AbstractSet<PostingListEntry>{

    PostingListIterator ifi;

    public PostingListEntrySet(PostingListIterator[] iterators, int postingListId,String indexDirectory,int lexiconSize, int maxScore)
    {
        synchronized(iterators){
            if (iterators[postingListId]==null)
                iterators[postingListId]=new PostingListIterator(postingListId,indexDirectory,lexiconSize,maxScore);
        }
        iterators[postingListId].initialisation(0,maxScore);
        ifi= iterators[postingListId];
    }

    public PostingListEntrySet(PostingListIterator[] iterators,int postingListId,String indexDirectory,int lexiconSize, int maxScore,int fromScore)
    {
        synchronized(iterators){
            if (iterators[postingListId]==null)
                iterators[postingListId]=new PostingListIterator(postingListId,indexDirectory,lexiconSize,maxScore);
        }
        iterators[postingListId].initialisation(fromScore,maxScore);
        ifi= iterators[postingListId];
    }

    public PostingListEntrySet(PostingListIterator[] iterators,int postingListId,String indexDirectory,int lexiconSize, int maxScore,int fromScore, int toScore)
    {
//        System.err.println("Total memory: "+Runtime.getRuntime().totalMemory()+"Free memory: "+Runtime.getRuntime().freeMemory()+"Max memory: "+Runtime.getRuntime().maxMemory());
        synchronized(iterators){
            if (iterators[postingListId]==null)
                iterators[postingListId]=new PostingListIterator(postingListId,indexDirectory,lexiconSize,maxScore);
        }
        iterators[postingListId].initialisation(fromScore,toScore);
        ifi= iterators[postingListId];
    }



    @Override
    public Iterator<PostingListEntry> iterator() {
        return ifi;
    }

    @Override
    public int size() {
        //throw new UnsupportedOperationException("Not supported yet.");
        return ifi.getPostingListPortionSize();
    }


}
